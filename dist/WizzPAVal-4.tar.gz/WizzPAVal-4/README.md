WizzSoup
* This module contains jokes(general,pragram related,maths) ,questions,challenges.
* This module will make your AI assistant or chatbot much simpler. As it performs random task to user based on their request.
```python
 #importing main function and getting some general jokes
 from WizzSoup import NorJokes
 NorJokes()
 
 #importing main function and getting program related jokes
 from WizzSoup import ProgJokes
 ProgJokes()

 #importing main function and getting maths related jokes
 from WizzSoup import MathJokes
 MathJokes()

 #importing main function and getting some challenges/tasks
 from WizzSoup import WizzChallenge
 WizzChallenge()

 #importing main function and getting some questions
 from WizzSoup import WizzQsn
 WizzQsn()

```
Developing WizzPAVal
* To install WizzPAVal, along with the tools you need to develop
   and run tests, run the following
  in your virtualenv.
```bash
$ pip install -e .[dev]
```
